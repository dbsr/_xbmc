dbsr's xbmc addons and scripts
